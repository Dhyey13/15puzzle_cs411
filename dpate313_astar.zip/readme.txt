Version: Python 3.7
- Just run the code. There are the test cases that are commented OR you can just 
enter the numbers manually by uncommenting the user prompt
- TO TEST heuristics: uncomment f1(node) for misplaced tiles in a_star algorithm, 
I've commented where to uncomment those as well.

************** SAMPLE OUTPUT ****************
The number of nodes visited 2920
States of moves are as follows:
Memory elapsed:  2572.0 kb
['R', 'U', 'L', 'L', 'D', 'R', 'D', 'R', 'D']
9  moves
Total searching time:  0.237 seconds