Version: Python 3.7
- Just run the code. There are the test cases that are commented OR you can just 
enter the numbers manually by uncommenting the user prompt

************SAMPLE OUTPUT**************
Memory elapsed:  24576 bytes
States of moves are as follows:
['R', 'U', 'L', 'L', 'D', 'R', 'D', 'R', 'D']
9  moves
The number of nodes visited 259
Total searching time:  0.007 seconds